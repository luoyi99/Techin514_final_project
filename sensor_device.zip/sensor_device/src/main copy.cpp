
// #include <Arduino.h>
// #include <BLEDevice.h>
// #include <BLEServer.h>
// #include <BLEUtils.h>
// #include <BLE2902.h>
// #include <stdlib.h>
// #include <Wire.h>
// #include <Adafruit_GFX.h>
// #include <Adafruit_SSD1306.h>

// #define SCREEN_WIDTH 128
// #define SCREEN_HEIGHT 32
// #define OLED_RESET -1 // Reset pin # (or -1 if sharing Arduino reset pin)
// #define OLED_ADDR 0x3C

// Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// BLEServer* pServer = NULL;
// BLECharacteristic* pCharacteristic = NULL;
// bool deviceConnected = false;
// bool oldDeviceConnected = false;
// unsigned long previousMillis = 0;
// const long interval = 1000;


// // TODO: Change the UUID to your own (any specific one works, but make sure they're different from others'). You can generate one here: https://www.uuidgenerator.net/
// #define SERVICE_UUID        "3095514c-86cb-45b8-82e4-0a52ba9ad6a2"
// #define CHARACTERISTIC_UUID "d6abe3ab-0226-4e46-b329-c54af4d2e6e4"

// class MyServerCallbacks : public BLEServerCallbacks {
//     void onConnect(BLEServer* pServer) {
//         deviceConnected = true;
//     };

//     void onDisconnect(BLEServer* pServer) {
//         deviceConnected = false;
//     }
// };

// void setup() {
//     Serial.begin(115200);
//     Serial.println("Starting BLE work!");

//     BLEDevice::init("XIAO_ESP32S3_BLE_Display");
//     pServer = BLEDevice::createServer();
//     pServer->setCallbacks(new MyServerCallbacks());
//     BLEService *pService = pServer->createService(SERVICE_UUID);
//     pCharacteristic = pService->createCharacteristic(
//         CHARACTERISTIC_UUID,
//         BLECharacteristic::PROPERTY_READ |
//         BLECharacteristic::PROPERTY_WRITE |
//         BLECharacteristic::PROPERTY_NOTIFY
//     );
//     pCharacteristic->addDescriptor(new BLE2902());
//     pCharacteristic->setValue("Hello World");
//     pService->start();
//     BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
//     pAdvertising->addServiceUUID(SERVICE_UUID);
//     pAdvertising->setScanResponse(true);
//     pAdvertising->setMinPreferred(0x06);
//     pAdvertising->setMinPreferred(0x12);
//     BLEDevice::startAdvertising();
//     Serial.println("Characteristic defined!");

//     if(!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
//         Serial.println(F("SSD1306 allocation failed"));
//         for(;;); // Don't proceed, loop forever
//     }
//     display.display();
//     delay(2000); // Pause for 2 seconds
//     display.clearDisplay();
// }

// void loop() {
//     if (deviceConnected) {
//         unsigned long currentMillis = millis();
//         if (currentMillis - previousMillis >= interval) {
//             // Assuming the value to display is the last received value.
//             String value = pCharacteristic->getValue();

//             display.clearDisplay();
//             display.setTextSize(1);
//             display.setTextColor(SSD1306_WHITE);
//             display.setCursor(0, 0);
//             display.println("Received Value:");
//             display.println(value); // Display received value
//             display.display();

//             previousMillis = currentMillis;
//             Serial.println("Notify value: " + value);
//         }
//     }

//     // Handle BLE connection status changes
//     if (!deviceConnected && oldDeviceConnected) {
//         delay(500);  // give the bluetooth stack the chance to get things ready
//         pServer->startAdvertising();  // restart advertising
//         Serial.println("Start advertising");
//         oldDeviceConnected = deviceConnected;
//     } else if (deviceConnected && !oldDeviceConnected) {
//         // Do tasks here on connecting if needed
//         oldDeviceConnected = deviceConnected;
//     }
// }
