// #include <a514-final-project_inferencing.h>
// #include <Wire.h>
// #include <Adafruit_MPU6050.h> // Include MPU6050 library. Make sure to install it from the Arduino Library Manager or from GitHub.

// /** Struct to link sensor axis name to sensor value function */
// typedef struct{
//     const char *name;
//     float *value;
//     uint8_t (*poll_sensor)(void);
//     bool (*init_sensor)(void);
//     int8_t status;  // -1 not used 0 used(unitialized) 1 used(initalized) 2 data sampled
// } eiSensors;

// /* Constant defines -------------------------------------------------------- */
// #define CONVERT_G_TO_MS2    9.80665f
// #define MAX_ACCEPTED_RANGE  2.0f        
// /** Number sensor axes used */
// #define N_SENSORS     7

// /* Forward declarations ------------------------------------------------------- */
// bool init_MPU6050(void);
// uint8_t poll_MPU6050(void);

// /* Private variables ------------------------------------------------------- */
// static const bool debug_nn = false; 
// static float data[N_SENSORS];
// static int8_t fusion_sensors[N_SENSORS];
// static int fusion_ix = 0;

// Adafruit_MPU6050 mpu6050;

// /** Used sensors value function connected to label name */
// eiSensors sensors[] =
// {
//     "accX", &data[0], &poll_MPU6050, &init_MPU6050, -1,
//     "accY", &data[1], &poll_MPU6050, &init_MPU6050, -1,
//     "accZ", &data[2], &poll_MPU6050, &init_MPU6050, -1,
//     // Assuming no ADC usage for simplicity, remove or adjust if you're using an ADC input
// };



// /**
//  * @brief Check if requested input list is valid sensor fusion, create sensor buffer
//  *
//  * @param[in]  input_list      Axes list to sample (ie. "accX + gyrY + magZ")
//  * @retval  false if invalid sensor_list
//  */
// static bool ei_connect_fusion_list(const char *input_list)
// {
//     char *buff;
//     bool is_fusion = false;

//     /* Copy const string in heap mem */
//     char *input_string = (char *)ei_malloc(strlen(input_list) + 1);
//     if (input_string == NULL) {
//         return false;
//     }
//     memset(input_string, 0, strlen(input_list) + 1);
//     strncpy(input_string, input_list, strlen(input_list));

//     /* Clear fusion sensor list */
//     memset(fusion_sensors, 0, N_SENSORS);
//     fusion_ix = 0;

//     buff = strtok(input_string, "+");

//     while (buff != NULL) { /* Run through buffer */
//         int8_t found_axis = 0;

//         is_fusion = false;
//         found_axis = ei_find_axis(buff);

//         if(found_axis >= 0) {
//             if(fusion_ix < N_SENSORS) {
//                 fusion_sensors[fusion_ix++] = found_axis;
//                 sensors[found_axis].status = 0;
//             }
//             is_fusion = true;
//         }

//         buff = strtok(NULL, "+ ");
//     }

//     ei_free(input_string);

//     return is_fusion;
// }

// /**
//  * @brief Return the sign of the number
//  *
//  * @param number
//  * @return int 1 if positive (or 0) -1 if negative
//  */
// float ei_get_sign(float number) {
//     return (number >= 0.0) ? 1.0 : -1.0;
// }


// bool init_MPU6050(void) {
//     static bool init_status = false;
//     if (!init_status) {
//         if (!mpu6050.begin()) {
//             Serial.println("Failed to find MPU6050 chip");
//             while (1) {
//                 delay(10);
//             }
//         }
//         mpu6050.setAccelerometerRange(MPU6050_RANGE_2_G);
//         mpu6050.setGyroRange(MPU6050_RANGE_250_DEG);
//         mpu6050.setFilterBandwidth(MPU6050_BAND_21_HZ);
//         init_status = true;
//     }
//     return init_status;
// }

// uint8_t poll_MPU6050(void) {
//     sensors_event_t a, g, temp;
//     mpu6050.getEvent(&a, &g, &temp);
//     data[0] = a.acceleration.x * CONVERT_G_TO_MS2;
//     data[1] = a.acceleration.y * CONVERT_G_TO_MS2;
//     data[2] = a.acceleration.z * CONVERT_G_TO_MS2;
//     return 0;
// }

// void setup() {
//     Serial.begin(115200);
//     while (!Serial); // Wait for the serial port to connect.
//     Serial.println("Edge Impulse Sensor Fusion Inference\r\n");

//     if(ei_connect_fusion_list(EI_CLASSIFIER_FUSION_AXES_STRING) == false) {
//         Serial.println("ERR: Errors in sensor list detected\r\n");
//         return;
//     }

//     for(int i = 0; i < fusion_ix; i++) {
//         if (sensors[fusion_sensors[i]].status == 0) {
//             sensors[fusion_sensors[i]].status = sensors[fusion_sensors[i]].init_sensor();
//             if (!sensors[fusion_sensors[i]].status) {
//               Serial.printf("%s axis sensor initialization failed.\r\n", sensors[fusion_sensors[i]].name);
//             }
//             else {
//               Serial.printf("%s axis sensor initialization successful.\r\n", sensors[fusion_sensors[i]].name);
//             }
//         }
//     }
// }

// void loop()
// {
//     ei_printf("\nStarting inferencing in 2 seconds...\r\n");

//     delay(2000);

//     if (EI_CLASSIFIER_RAW_SAMPLES_PER_FRAME != fusion_ix) {
//         ei_printf("ERR: Sensors don't match the sensors required in the model\r\n"
//         "Following sensors are required: %s\r\n", EI_CLASSIFIER_FUSION_AXES_STRING);
//         return;
//     }

//     ei_printf("Sampling...\r\n");

//     // Allocate a buffer here for the values we'll read from the sensor
//     float buffer[EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE] = { 0 };

//     for (size_t ix = 0; ix < EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE; ix += EI_CLASSIFIER_RAW_SAMPLES_PER_FRAME) {
//         // Determine the next tick (and then sleep later)
//         int64_t next_tick = (int64_t)micros() + ((int64_t)EI_CLASSIFIER_INTERVAL_MS * 1000);

//         for(int i = 0; i < fusion_ix; i++) {
//             if (sensors[fusion_sensors[i]].status == 1) {
//                 sensors[fusion_sensors[i]].poll_sensor();
//                 sensors[fusion_sensors[i]].status = 2;
//             }
//             if (sensors[fusion_sensors[i]].status == 2) {
//                 buffer[ix + i] = *sensors[fusion_sensors[i]].value;
//                 //ei_printf("%d %f\n", fusion_sensors[i], buffer[ix + i]);
//                 sensors[fusion_sensors[i]].status = 1;
//             }
//         }

//         int64_t wait_time = next_tick - (int64_t)micros();

//         if(wait_time > 0) {
//             delayMicroseconds(wait_time);
//         }
//     }

//     // Turn the raw buffer in a signal which we can the classify
//     signal_t signal;
//     int err = numpy::signal_from_buffer(buffer, EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE, &signal);
//     if (err != 0) {
//         ei_printf("ERR:(%d)\r\n", err);
//         return;
//     }

//     // Run the classifier
//     ei_impulse_result_t result = { 0 };

//     err = run_classifier(&signal, &result, debug_nn);
//     if (err != EI_IMPULSE_OK) {
//         ei_printf("ERR:(%d)\r\n", err);
//         return;
//     }

//     // print the predictions
//     ei_printf("Predictions (DSP: %d ms., Classification: %d ms., Anomaly: %d ms.):\r\n",
//         result.timing.dsp, result.timing.classification, result.timing.anomaly);
//     for (size_t ix = 0; ix < EI_CLASSIFIER_LABEL_COUNT; ix++) {
//         ei_printf("%s: %.5f\r\n", result.classification[ix].label, result.classification[ix].value);
//     }
// #if EI_CLASSIFIER_HAS_ANOMALY == 1
//     ei_printf("    anomaly score: %.3f\r\n", result.anomaly);
// #endif
// }

// #if !defined(EI_CLASSIFIER_SENSOR) || (EI_CLASSIFIER_SENSOR != EI_CLASSIFIER_SENSOR_FUSION && EI_CLASSIFIER_SENSOR != EI_CLASSIFIER_SENSOR_ACCELEROMETER)
// #error "Invalid model for current sensor"
// #endif



#include <PulseSensorPlayground.h>     // Includes the PulseSensorPlayground Library.   
#include <Adafruit_MPU6050.h>
#include <Wire.h>
#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEScan.h>
#include <BLEAdvertisedDevice.h>
// Client Code
#include "BLEDevice.h"
//#include "BLEScan.h"

//  Variables
const int PushButtonPin = D8; // Push button connected to digital pin 8
bool exerciseSessionStarted = true;

int jumpingJacksCount = 0;

// MPU6050 sensor
Adafruit_MPU6050 mpu;


// The remote service we wish to connect to.
static BLEUUID serviceUUID("014805bf-7587-47e5-8965-b11fef29d012");
// The characteristic of the remote service we are interested in.
static BLEUUID    charUUID("47b36193-f67b-4a77-ad27-0cafb5dd7a91");
static boolean doConnect = false;
static boolean connected = false;
static boolean doScan = false;
static BLERemoteCharacteristic* pRemoteCharacteristic;
static BLEAdvertisedDevice* myDevice;


static void notifyCallback(
  BLERemoteCharacteristic* pBLERemoteCharacteristic,
  uint8_t* pData,
  size_t length,
  bool isNotify) {
    // TODO: add codes to handle the data received from the server, and call the data aggregation function to process the data

    // TODO: change the following code to customize your own data format for printing
    Serial.print("Notify callback for characteristic ");
    Serial.print(pBLERemoteCharacteristic->getUUID().toString().c_str());
    Serial.print(" of data length ");
    Serial.println(length);
    Serial.print("data: ");
    Serial.write(pData, length);
    Serial.println();
}

class MyClientCallback : public BLEClientCallbacks {
  void onConnect(BLEClient* pclient) {
  }

  void onDisconnect(BLEClient* pclient) {
    connected = false;
    Serial.println("onDisconnect");
  }
};

bool connectToServer() {
    Serial.print("Forming a connection to ");
    Serial.println(myDevice->getAddress().toString().c_str());

    BLEClient*  pClient  = BLEDevice::createClient();
    Serial.println(" - Created client");

    pClient->setClientCallbacks(new MyClientCallback());

    // Connect to the remove BLE Server.
    pClient->connect(myDevice);  // if you pass BLEAdvertisedDevice instead of address, it will be recognized type of peer device address (public or private)
    Serial.println(" - Connected to server");
    pClient->setMTU(517); //set client to request maximum MTU from server (default is 23 otherwise)

    // Obtain a reference to the service we are after in the remote BLE server.
    BLERemoteService* pRemoteService = pClient->getService(serviceUUID);
    if (pRemoteService == nullptr) {
      Serial.print("Failed to find our service UUID: ");
      Serial.println(serviceUUID.toString().c_str());
      pClient->disconnect();
      return false;
    }
    Serial.println(" - Found our service");

    // Obtain a reference to the characteristic in the service of the remote BLE server.
    pRemoteCharacteristic = pRemoteService->getCharacteristic(charUUID);
    if (pRemoteCharacteristic == nullptr) {
      Serial.print("Failed to find our characteristic UUID: ");
      Serial.println(charUUID.toString().c_str());
      pClient->disconnect();
      return false;
    }
    Serial.println(" - Found our characteristic");

    // Read the value of the characteristic.
    if(pRemoteCharacteristic->canRead()) {
      std::string value = pRemoteCharacteristic->readValue();
      Serial.print("The characteristic value was: ");
      Serial.println(value.c_str());
    }

    if(pRemoteCharacteristic->canNotify())
      pRemoteCharacteristic->registerForNotify(notifyCallback);

    connected = true;
    return true;
}
/**
 * Scan for BLE servers and find the first one that advertises the service we are looking for.
 */
class MyAdvertisedDeviceCallbacks: public BLEAdvertisedDeviceCallbacks {
  /**
   * Called for each advertising BLE server.
   */
  void onResult(BLEAdvertisedDevice advertisedDevice) {
    Serial.print("BLE Advertised Device found: ");
    Serial.println(advertisedDevice.toString().c_str());

    // We have found a device, let us now see if it contains the service we are looking for.
    if (advertisedDevice.haveServiceUUID() && advertisedDevice.isAdvertisingService(serviceUUID)) {

      BLEDevice::getScan()->stop();
      myDevice = new BLEAdvertisedDevice(advertisedDevice);
      doConnect = true;
      doScan = true;

    } // Found our server
  } // onResult
}; // MyAdvertisedDeviceCallbacks



void setup() {   

  Serial.begin(115200);          // For Serial Monitor

  pinMode(PushButtonPin, INPUT_PULLUP);  // Initialize the push button pin as an input with internal pull-up resistor

  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050 chip");
    while (1) {
      delay(10);
    }
  }
  Serial.println("MPU6050 Found!");


  Serial.println("Starting Arduino BLE Client application...");
  BLEDevice::init("");

  // Retrieve a Scanner and set the callback we want to use to be informed when we
  // have detected a new device.  Specify that we want active scanning and start the
  // scan to run for 5 seconds.
  BLEScan* pBLEScan = BLEDevice::getScan();
  pBLEScan->setAdvertisedDeviceCallbacks(new MyAdvertisedDeviceCallbacks());
  pBLEScan->setInterval(1349);
  pBLEScan->setWindow(449);
  pBLEScan->setActiveScan(true);
  pBLEScan->start(5, false);


  //setupt motion detection
  mpu.setHighPassFilter(MPU6050_HIGHPASS_0_63_HZ);
  mpu.setMotionDetectionThreshold(1);
  mpu.setMotionDetectionDuration(20);
  mpu.setInterruptPinLatch(true);	// Keep it latched.  Will turn off when reinitialized.
  mpu.setInterruptPinPolarity(true);
  mpu.setMotionInterrupt(true);


}



void loop() {
    
  // If the flag "doConnect" is true then we have scanned for and found the desired
  // BLE Server with which we wish to connect.  Now we connect to it.  Once we are
  // connected we set the connected flag to be true.
  if (doConnect == true) {
    if (connectToServer()) {
      Serial.println("We are now connected to the BLE Server.");
    } else {
      Serial.println("We have failed to connect to the server; there is nothin more we will do.");
    }
    doConnect = false;
  }

  // If we are connected to a peer BLE Server, update the characteristic each time we are reached
  // with the current time since boot.
  if (connected) {
    String newValue = "Time since boot: " + String(millis()/1000);
    Serial.println("Setting new characteristic value to \"" + newValue  + "\"");

    // Set the characteristic's value to be the array of bytes that is actually a string.
    pRemoteCharacteristic->writeValue(newValue.c_str(), newValue.length());
  }else if(doScan){
    BLEDevice::getScan()->start(0);  // this is just example to start scan after disconnect, most likely there is better way to do it in arduino
  }





  bool pushButtonState = digitalRead(PushButtonPin);  // Read the state of the push button
  // Serial.print(pushButtonState);

  // If the push button is pressed, change the exercise session state. 
  // If the exercise session has started, stop it. If it hasn't started, start it.
  if (pushButtonState  == 01 ) {
    if (exerciseSessionStarted){
      Serial.println("Exercise session stopped");
      exerciseSessionStarted = false;
    }
    else {
      Serial.println("Exercise session started");
      exerciseSessionStarted = true;
      jumpingJacksCount = 0;
    }
  } 

  // If the exercise session has started, process jumping jacks data
  if (exerciseSessionStarted){
    
    if(mpu.getMotionInterruptStatus()) {
      /* Get new sensor events with the readings */
      sensors_event_t a, g, temp;
      mpu.getEvent(&a, &g, &temp);

      /* Print out the values */
      Serial.print("AccelX:");
      Serial.print(a.acceleration.x);
      Serial.print(",");
      Serial.print("AccelY:");
      Serial.print(a.acceleration.y);
      Serial.print(",");
      Serial.print("AccelZ:");
      Serial.print(a.acceleration.z);
      Serial.print(", ");
      Serial.print("GyroX:");
      Serial.print(g.gyro.x);
      Serial.print(",");
      Serial.print("GyroY:");
      Serial.print(g.gyro.y);
      Serial.print(",");
      Serial.print("GyroZ:");
      Serial.print(g.gyro.z);
      Serial.println("");
    }
  }


  delay(500);                    // considered best practice in a simple sketch.

}
